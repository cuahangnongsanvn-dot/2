# Match-3 Smart Bot Pro (Version 2.0)
- Nút bong bóng nổi (Floating Widget) kéo thả tiện lợi, không cần chuyển tab gây văng game.
- Bộ lọc chống nổ 2 tầng (Stability Double-Check): Chỉ lật cờ khi bàn cờ đứng yên 100%.
