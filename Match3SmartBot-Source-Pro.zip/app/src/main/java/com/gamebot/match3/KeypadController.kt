package com.gamebot.match3

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import kotlin.random.Random

class KeypadController(private val service: AccessibilityService) {

    private val handler = Handler(Looper.getMainLooper())

    data class PointF(val x: Float, val y: Float)

    fun getKeypadPositions(screenWidth: Int, screenHeight: Int): Map<String, PointF> {
        val padTop = screenHeight * 0.70f
        val padBottom = screenHeight * 0.98f
        val padHeight = padBottom - padTop
        val colWidth = screenWidth / 6f
        val rowHeight = padHeight / 4f

        return mapOf(
            "SOFT_LEFT" to PointF(colWidth * 3.5f, padTop + rowHeight * 0.5f), // Phím L
            "UP"        to PointF(colWidth * 4.5f, padTop + rowHeight * 1.5f), // Phím ↑
            "DOWN"      to PointF(colWidth * 4.5f, padTop + rowHeight * 3.5f), // Phím ↓
            "LEFT"      to PointF(colWidth * 3.5f, padTop + rowHeight * 2.5f), // Phím ←
            "RIGHT"     to PointF(colWidth * 5.5f, padTop + rowHeight * 2.5f), // Phím →
            "FIRE"      to PointF(colWidth * 4.5f, padTop + rowHeight * 2.5f)  // Phím F
        )
    }

    /**
     * Định vị con trỏ xanh bằng cách kiểm tra viền ô
     */
    fun findAccurateCursor(bitmap: Bitmap, bLeft: Int, bTop: Int, cW: Int, cH: Int): Pair<Int, Int>? {
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val cx = bLeft + c * cW + cW / 2
                val cy = bTop + r * cH + cH / 2
                val leftX = cx - cW / 2 + 1
                var matchCount = 0

                for (dy in -8..8 step 2) {
                    val py = cy + dy
                    if (leftX in 0 until bitmap.width && py in 0 until bitmap.height) {
                        val p = bitmap.getPixel(leftX, py)
                        val pr = Color.red(p)
                        val pg = Color.green(p)
                        val pb = Color.blue(p)
                        // Viền lục bảo: Green trội hơn Red và Blue
                        if (pg > pr + 25 && pb > pr + 15 && pg in 85..195) {
                            matchCount++
                        }
                    }
                }

                if (matchCount >= 5) {
                    return Pair(r, c)
                }
            }
        }
        return null
    }

    fun executeMoveWithKeys(
        currentPos: Pair<Int, Int>,
        targetFrom: Pair<Int, Int>,
        targetTo: Pair<Int, Int>,
        keyPositions: Map<String, PointF>,
        onFinished: () -> Unit
    ) {
        val keySequence = mutableListOf<PointF>()

        val dRow = targetFrom.first - currentPos.first
        val dCol = targetFrom.second - currentPos.second

        val vKey = if (dRow > 0) keyPositions["DOWN"] else keyPositions["UP"]
        repeat(Math.abs(dRow)) { vKey?.let { keySequence.add(it) } }

        val hKey = if (dCol > 0) keyPositions["RIGHT"] else keyPositions["LEFT"]
        repeat(Math.abs(dCol)) { hKey?.let { keySequence.add(it) } }

        // Bấm F chọn ô
        keyPositions["FIRE"]?.let { keySequence.add(it) }

        // Bấm hướng mũi tên lật
        val swapRow = targetTo.first - targetFrom.first
        val swapCol = targetTo.second - targetFrom.second

        when {
            swapRow == 1  -> keyPositions["DOWN"]?.let { keySequence.add(it) }
            swapRow == -1 -> keyPositions["UP"]?.let { keySequence.add(it) }
            swapCol == 1  -> keyPositions["RIGHT"]?.let { keySequence.add(it) }
            swapCol == -1 -> keyPositions["LEFT"]?.let { keySequence.add(it) }
        }

        pressKeySequence(keySequence, 0, onFinished)
    }

    fun castSkill1(keyPositions: Map<String, PointF>, onDone: () -> Unit) {
        val softLeft = keyPositions["SOFT_LEFT"] ?: return
        val fire = keyPositions["FIRE"] ?: return

        tapKey(softLeft.x, softLeft.y) {
            handler.postDelayed({
                tapKey(fire.x, fire.y) {
                    handler.postDelayed({
                        tapKey(softLeft.x, softLeft.y) {
                            handler.postDelayed({
                                onDone()
                            }, 2500)
                        }
                    }, 240)
                }
            }, 240)
        }
    }

    private fun pressKeySequence(sequence: List<PointF>, index: Int, onComplete: () -> Unit) {
        if (index >= sequence.size) {
            onComplete()
            return
        }

        val target = sequence[index]
        tapKey(target.x, target.y) {
            val delay = Random.nextLong(160, 240)
            handler.postDelayed({
                pressKeySequence(sequence, index + 1, onComplete)
            }, delay)
        }
    }

    private fun tapKey(x: Float, y: Float, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val pressDuration = Random.nextLong(60, 90)
        val stroke = GestureDescription.StrokeDescription(path, 0, pressDuration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) = done()
            override fun onCancelled(gestureDescription: GestureDescription?) = done()
        }, null)
    }
}
