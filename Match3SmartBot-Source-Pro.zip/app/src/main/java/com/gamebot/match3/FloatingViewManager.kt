package com.gamebot.match3

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView

class FloatingViewManager(
    private val context: Context,
    private val onToggleBot: (Boolean) -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var floatingView: TextView? = null
    private var isRunning = false

    fun show() {
        if (floatingView != null) return

        floatingView = TextView(context).apply {
            text = "BOT: TẮT"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(24, 20, 24, 20)
            background = getPillBackground(Color.parseColor("#D50000")) // Đỏ khi tắt
            elevation = 16f
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 200
        }

        // Xử lý kéo thả di chuyển hoặc chạm để bật/tắt
        floatingView?.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isClick = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        params.x = initialX + dx
                        params.y = initialY + dy
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            toggleState()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleState() {
        isRunning = !isRunning
        updateUI()
        onToggleBot(isRunning)
    }

    fun setRunning(running: Boolean) {
        isRunning = running
        updateUI()
    }

    private fun updateUI() {
        floatingView?.let { view ->
            if (isRunning) {
                view.text = "BOT: BẬT"
                view.background = getPillBackground(Color.parseColor("#00C853")) // Xanh khi bật
            } else {
                view.text = "BOT: TẮT"
                view.background = getPillBackground(Color.parseColor("#D50000")) // Đỏ khi dừng
            }
        }
    }

    private fun getPillBackground(color: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 50f
            setColor(color)
            setStroke(3, Color.WHITE)
        }
    }

    fun remove() {
        floatingView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {}
            floatingView = null
        }
    }
}
