package com.gamebot.match3

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class GameBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private lateinit var keyController: KeypadController
    private var floatingManager: FloatingViewManager? = null

    // Bộ nhớ kiểm tra độ ổn định của bàn cờ (Chống quét lúc nổ)
    private var lastBoard: Array<IntArray>? = null
    private var lastCursor: Pair<Int, Int>? = null

    companion object {
        var instance: GameBotService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        keyController = KeypadController(this)
        Toast.makeText(this, "Game Bot Service đã kích hoạt!", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        stopAuto()
    }

    fun showFloatingWidget() {
        if (floatingManager == null) {
            floatingManager = FloatingViewManager(applicationContext) { start ->
                if (start) startAuto() else stopAuto()
            }
        }
        floatingManager?.show()
    }

    fun startAuto() {
        if (isRunning) return
        isRunning = true
        lastBoard = null
        lastCursor = null
        floatingManager?.setRunning(true)
        Toast.makeText(this, "Bot bắt đầu đánh...", Toast.LENGTH_SHORT).show()
        loopTurn()
    }

    fun stopAuto() {
        isRunning = false
        lastBoard = null
        lastCursor = null
        floatingManager?.setRunning(false)
        Toast.makeText(this, "Đã tạm dừng Bot.", Toast.LENGTH_SHORT).show()
    }

    fun isBotRunning(): Boolean = isRunning

    private fun loopTurn() {
        if (!isRunning) return

        takeScreenshot(Display.DEFAULT_DISPLAY, applicationContext.mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                    ?.copy(Bitmap.Config.ARGB_8888, false)
                screenshot.hardwareBuffer.close()

                if (bitmap != null) {
                    processScreen(bitmap)
                } else {
                    retryNext(800)
                }
            }

            override fun onFailure(errorCode: Int) {
                retryNext(1000)
            }
        })
    }

    private fun processScreen(bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height

        val boardLeft = (width * 0.0289f).toInt()
        val cellW = (width * 0.1178f).toInt()
        val boardTop = (height * 0.1040f).toInt()
        val cellH = (height * 0.0520f).toInt()

        val keyPositions = keyController.getKeypadPositions(width, height)

        // BƯỚC 1: Tìm con trỏ xanh lục bảo
        val currentCursor = keyController.findAccurateCursor(bitmap, boardLeft, boardTop, cellW, cellH)
        if (currentCursor == null) {
            // Không thấy con trỏ (đang hiệu ứng nổ / lượt quái đánh) -> Reset bộ nhớ và chờ
            lastBoard = null
            lastCursor = null
            retryNext(600)
            return
        }

        // BƯỚC 2: Kiểm tra thanh Mana (Bát quái đầy -> xả Xích Lôi Công)
        val checkManaX = (width * 0.28f).toInt()
        val checkManaY = (height * 0.54f).toInt()
        val manaPixel = bitmap.getPixel(checkManaX, checkManaY)
        val manaHsv = FloatArray(3)
        Color.RGBToHSV(Color.red(manaPixel), Color.green(manaPixel), Color.blue(manaPixel), manaHsv)
        val isManaFull = (manaHsv[0] in 85f..150f && manaHsv[1] > 0.40f)

        if (isManaFull) {
            keyController.castSkill1(keyPositions) {
                lastBoard = null
                lastCursor = null
                retryNext(1500)
            }
            return
        }

        // BƯỚC 3: Quét 64 ô cờ
        val currentBoard = Array(8) { IntArray(8) }
        var hasUnknownGem = false

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val cx = boardLeft + c * cellW + cellW / 2
                val cy = boardTop + r * cellH + cellH / 2
                val gem = getGemAtCenter(bitmap, cx, cy)
                if (gem == BoardSolver.EMPTY) {
                    hasUnknownGem = true // Vẫn còn khói trắng hoặc ô đang rơi chưa cố định
                }
                currentBoard[r][c] = gem
            }
        }

        // BƯỚC 4: BỘ LỌC CHỐNG NỔ 2 TẦNG (DOUBLE-CHECK ỔN ĐỊNH)
        // Nếu có ô bị mờ/khói nổ, hoặc bàn cờ lần này khác lần trước -> Cờ chưa dừng rơi!
        if (hasUnknownGem || !isBoardEqual(currentBoard, lastBoard) || currentCursor != lastCursor) {
            // Lưu lại khung hình hiện tại và đợi 350ms quét lại để so sánh
            lastBoard = currentBoard
            lastCursor = currentCursor
            retryNext(350)
            return
        }

        // ĐẾN ĐÂY: Bàn cờ và con trỏ đã hoàn toàn ĐỨNG YÊN qua 2 khung hình liên tiếp!
        val bestMove = BoardSolver.findBestMove(currentBoard, isMyHpLow = false, needsMana = !isManaFull)

        if (bestMove != null) {
            val targetFrom = Pair(bestMove.r1, bestMove.c1)
            val targetTo = Pair(bestMove.r2, bestMove.c2)

            keyController.executeMoveWithKeys(currentCursor, targetFrom, targetTo, keyPositions) {
                lastBoard = null
                lastCursor = null
                // Sau khi di chuyển và lật xong, đợi 1.5s cho hiệu ứng nổ ban đầu diễn ra
                retryNext(1500)
            }
        } else {
            // Thế cờ tạm thời chưa nhận diện được nước ăn, đợi 800ms
            retryNext(800)
        }
    }

    private fun isBoardEqual(b1: Array<IntArray>, b2: Array<IntArray>?): Boolean {
        if (b2 == null) return false
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                if (b1[r][c] != b2[r][c]) return false
            }
        }
        return true
    }

    private fun getGemAtCenter(bitmap: Bitmap, cx: Int, cy: Int): Int {
        var tr = 0
        var tg = 0
        var tb = 0
        var count = 0

        for (dx in -1..1) {
            for (dy in -1..1) {
                val px = cx + dx
                val py = cy + dy
                if (px in 0 until bitmap.width && py in 0 until bitmap.height) {
                    val p = bitmap.getPixel(px, py)
                    tr += Color.red(p)
                    tg += Color.green(p)
                    tb += Color.blue(p)
                    count++
                }
            }
        }

        if (count == 0) return BoardSolver.EMPTY

        val avgR = tr / count
        val avgG = tg / count
        val avgB = tb / count

        val hsv = FloatArray(3)
        Color.RGBToHSV(avgR, avgG, avgB, hsv)
        val h = hsv[0]
        val s = hsv[1]
        val v = hsv[2]

        return when {
            s < 0.12f && v >= 0.92f -> BoardSolver.PEACH
            s < 0.22f && v < 0.90f -> BoardSolver.SWORD
            h in 85f..140f -> BoardSolver.STAR
            h in 32f..65f && s > 0.50f -> BoardSolver.GOLD
            h in 175f..220f && s > 0.35f -> BoardSolver.BAGUA
            h in 245f..285f && s > 0.22f -> BoardSolver.DROP
            h in 310f..350f && s > 0.40f -> BoardSolver.HEART
            else -> BoardSolver.EMPTY
        }
    }

    private fun retryNext(delayMs: Long) {
        handler.postDelayed({ loopTurn() }, delayMs)
    }

    override fun onDestroy() {
        isRunning = false
        floatingManager?.remove()
        floatingManager = null
        instance = null
        super.onDestroy()
    }
}
