package com.gamebot.match3

object BoardSolver {
    const val EMPTY = 0
    const val SWORD = 1   // Kiếm: Sát thương
    const val HEART = 2   // Tim: Hồi phục
    const val BAGUA = 3   // Bát quái: Mana (Tuyệt chiêu)
    const val STAR  = 4   // Sao xanh: EXP
    const val GOLD  = 5   // Vàng
    const val PEACH = 6   // Đào
    const val DROP  = 7   // Giọt tím

    data class Move(val r1: Int, val c1: Int, val r2: Int, val c2: Int, val score: Int)

    fun findBestMove(board: Array<IntArray>, isMyHpLow: Boolean = false, needsMana: Boolean = true): Move? {
        var bestMove: Move? = null
        var maxNetScore = Int.MIN_VALUE

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                // Thử hoán đổi sang phải
                if (c + 1 < 8) {
                    val score = evaluateMinimaxMove(board, r, c, r, c + 1, isMyHpLow, needsMana)
                    if (score > maxNetScore) {
                        maxNetScore = score
                        bestMove = Move(r, c, r, c + 1, score)
                    }
                }
                // Thử hoán đổi xuống dưới
                if (r + 1 < 8) {
                    val score = evaluateMinimaxMove(board, r, c, r + 1, c, isMyHpLow, needsMana)
                    if (score > maxNetScore) {
                        maxNetScore = score
                        bestMove = Move(r, c, r + 1, c, score)
                    }
                }
            }
        }
        return if (maxNetScore > 0) bestMove else null
    }

    private fun evaluateMinimaxMove(
        board: Array<IntArray>,
        r1: Int, c1: Int, r2: Int, c2: Int,
        isMyHpLow: Boolean,
        needsMana: Boolean
    ): Int {
        val t1 = board[r1][c1]
        val t2 = board[r2][c2]
        if (t1 == EMPTY || t2 == EMPTY || t1 == t2) return Int.MIN_VALUE

        board[r1][c1] = t2
        board[r2][c2] = t1

        val match1 = getMatchSize(board, r1, c1)
        val match2 = getMatchSize(board, r2, c2)
        val maxMyMatch = maxOf(match1, match2)

        if (maxMyMatch < 3) {
            board[r1][c1] = t1
            board[r2][c2] = t2
            return Int.MIN_VALUE
        }

        var myGain = 0
        val gemType = if (match1 >= 3) board[r1][c1] else board[r2][c2]

        // ƯU TIÊN 1: Ăn 4+ được THÊM LƯỢT (Cực kỳ giá trị)
        if (maxMyMatch >= 4) {
            myGain += 50000 + (maxMyMatch - 4) * 15000
        }

        // ƯU TIÊN 2: Loại ngọc
        myGain += when (gemType) {
            BAGUA -> if (needsMana) 12000 else 900 // Gom Mana dùng Xích Lôi Công
            HEART -> if (isMyHpLow) 9000 else 1000
            SWORD -> if (!needsMana) 5000 else 2500
            STAR, GOLD, PEACH, DROP -> 300
            else -> 100
        }

        // Ưu tiên ăn tầng dưới (kéo nổ chuỗi dây chuyền)
        myGain += maxOf(r1, r2) * 50

        // PHÒNG THỦ: Kiểm tra xem quái có ăn được thế nguy hiểm không
        var enemyThreat = 0
        if (maxMyMatch < 4) {
            enemyThreat = scanBestEnemyThreat(board)
        }

        board[r1][c1] = t1
        board[r2][c2] = t2

        return myGain - enemyThreat
    }

    private fun scanBestEnemyThreat(b: Array<IntArray>): Int {
        var highestThreat = 0
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                if (c + 1 < 8) highestThreat = maxOf(highestThreat, checkSimpleSwapThreat(b, r, c, r, c + 1))
                if (r + 1 < 8) highestThreat = maxOf(highestThreat, checkSimpleSwapThreat(b, r, c, r + 1, c))
            }
        }
        return highestThreat
    }

    private fun checkSimpleSwapThreat(b: Array<IntArray>, r1: Int, c1: Int, r2: Int, c2: Int): Int {
        val t1 = b[r1][c1]
        val t2 = b[r2][c2]
        if (t1 == EMPTY || t2 == EMPTY || t1 == t2) return 0

        b[r1][c1] = t2
        b[r2][c2] = t1

        val m1 = getMatchSize(b, r1, c1)
        val m2 = getMatchSize(b, r2, c2)
        val maxM = maxOf(m1, m2)

        var threat = 0
        if (maxM >= 3) {
            val gem = if (m1 >= 3) b[r1][c1] else b[r2][c2]
            threat = if (maxM >= 4) 20000 else 0
            threat += when (gem) {
                SWORD -> 5000
                BAGUA -> 3000
                else -> 500
            }
        }

        b[r1][c1] = t1
        b[r2][c2] = t2
        return threat
    }

    private fun getMatchSize(b: Array<IntArray>, r: Int, c: Int): Int {
        val type = b[r][c]
        if (type == EMPTY) return 0

        var horiz = 1
        var left = c - 1
        while (left >= 0 && b[r][left] == type) { horiz++; left-- }
        var right = c + 1
        while (right < 8 && b[r][right] == type) { horiz++; right++ }

        var vert = 1
        var up = r - 1
        while (up >= 0 && b[up][c] == type) { vert++; up-- }
        var down = r + 1
        while (down < 8 && b[down][c] == type) { vert++; down++ }

        return maxOf(if (horiz >= 3) horiz else 0, if (vert >= 3) vert else 0)
    }
}
