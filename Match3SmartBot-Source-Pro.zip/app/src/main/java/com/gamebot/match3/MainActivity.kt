package com.gamebot.match3

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var tvPermOverlay: TextView
    private lateinit var tvPermAccessibility: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPermOverlay = findViewById(R.id.tvPermOverlay)
        tvPermAccessibility = findViewById(R.id.tvPermAccessibility)

        val btnGrantOverlay = findViewById<MaterialButton>(R.id.btnGrantOverlay)
        val btnGrantAccessibility = findViewById<MaterialButton>(R.id.btnGrantAccessibility)
        val btnShowOverlay = findViewById<MaterialButton>(R.id.btnShowOverlay)

        // 1. Quyền vẽ lên ứng dụng khác (Overlay)
        btnGrantOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:\$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Phiên bản Android không yêu cầu quyền này", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Quyền Dịch vụ Trợ năng
        btnGrantAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        // 3. Hiện nút bong bóng nổi và vào game
        btnShowOverlay.setOnClickListener {
            val service = GameBotService.instance
            if (service == null) {
                Toast.makeText(this, "Vui lòng bật quyền Dịch vụ Trợ năng trước!", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Vui lòng cấp quyền Vẽ lên ứng dụng khác trước!", Toast.LENGTH_LONG).show()
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:\$packageName")
                )
                startActivity(intent)
                return@setOnClickListener
            }

            // Hiện nút nổi trên màn hình
            service.showFloatingWidget()
            Toast.makeText(this, "Đã hiện nút nổi! Bạn hãy vào game.", Toast.LENGTH_SHORT).show()
            moveTaskToBack(true) // Thu nhỏ app
        }
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatus()
    }

    private fun updatePermissionStatus() {
        // Kiểm tra quyền Overlay
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        if (hasOverlay) {
            tvPermOverlay.text = "1. Quyền vẽ lên app khác: ĐÃ CẤP SẴN SÀNG"
            tvPermOverlay.setTextColor(Color.parseColor("#00E676"))
        } else {
            tvPermOverlay.text = "1. Quyền vẽ lên app khác: CHƯA CẤP (Bấm nút dưới)"
            tvPermOverlay.setTextColor(Color.parseColor("#FF5252"))
        }

        // Kiểm tra quyền Accessibility
        val service = GameBotService.instance
        if (service != null) {
            tvPermAccessibility.text = "2. Quyền Trợ năng: ĐÃ BẬT SẴN SÀNG"
            tvPermAccessibility.setTextColor(Color.parseColor("#00E676"))
        } else {
            tvPermAccessibility.text = "2. Quyền Trợ năng: CHƯA BẬT (Bấm nút dưới)"
            tvPermAccessibility.setTextColor(Color.parseColor("#FF5252"))
        }
    }
}
