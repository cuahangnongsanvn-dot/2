# Match-3 Smart Bot
Updated with exact coordinates and calibrated HSV classifier.
