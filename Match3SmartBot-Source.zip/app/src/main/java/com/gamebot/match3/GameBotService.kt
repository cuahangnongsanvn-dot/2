package com.gamebot.match3

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class GameBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private lateinit var keyController: KeypadController

    companion object {
        var instance: GameBotService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        keyController = KeypadController(this)
        Toast.makeText(this, "Game Bot Service đã kích hoạt sẵn sàng!", Toast.LENGTH_SHORT).show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        isRunning = false
    }

    fun startAuto() {
        if (isRunning) return
        isRunning = true
        Toast.makeText(this, "Bắt đầu tự động đánh chuẩn xác...", Toast.LENGTH_SHORT).show()
        loopTurn()
    }

    fun stopAuto() {
        isRunning = false
        Toast.makeText(this, "Đã dừng Bot.", Toast.LENGTH_SHORT).show()
    }

    fun isBotRunning(): Boolean = isRunning

    private fun loopTurn() {
        if (!isRunning) return

        takeScreenshot(Display.DEFAULT_DISPLAY, applicationContext.mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                    ?.copy(Bitmap.Config.ARGB_8888, false)
                screenshot.hardwareBuffer.close()

                if (bitmap != null) {
                    processScreen(bitmap)
                } else {
                    retryNext(1000)
                }
            }

            override fun onFailure(errorCode: Int) {
                retryNext(1500)
            }
        })
    }

    private fun processScreen(bitmap: Bitmap) {
        val width = bitmap.width
        val height = bitmap.height

        val boardLeft = (width * 0.0289f).toInt()
        val cellW = (width * 0.1178f).toInt()
        val boardTop = (height * 0.1040f).toInt()
        val cellH = (height * 0.0520f).toInt()

        val keyPositions = keyController.getKeypadPositions(width, height)

        val cursor = findAccurateCursor(bitmap, boardLeft, boardTop, cellW, cellH)
        if (cursor == null) {
            retryNext(800)
            return
        }

        val checkManaX = (width * 0.28f).toInt()
        val checkManaY = (height * 0.54f).toInt()
        val manaPixel = bitmap.getPixel(checkManaX, checkManaY)
        val manaHsv = FloatArray(3)
        Color.RGBToHSV(Color.red(manaPixel), Color.green(manaPixel), Color.blue(manaPixel), manaHsv)

        val isManaFull = (manaHsv[0] in 85f..150f && manaHsv[1] > 0.40f)

        if (isManaFull) {
            keyController.castSkill1(keyPositions) {
                retryNext(1400)
            }
            return
        }

        val board = Array(8) { IntArray(8) }
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val cx = boardLeft + c * cellW + cellW / 2
                val cy = boardTop + r * cellH + cellH / 2

                board[r][c] = getGemAtCenter(bitmap, cx, cy)
            }
        }

        val bestMove = BoardSolver.findBestMove(board, isMyHpLow = false, needsMana = !isManaFull)

        if (bestMove != null) {
            val targetFrom = Pair(bestMove.r1, bestMove.c1)
            val targetTo = Pair(bestMove.r2, bestMove.c2)

            keyController.executeMoveWithKeys(cursor, targetFrom, targetTo, keyPositions) {
                retryNext(1500)
            }
        } else {
            retryNext(1000)
        }
    }

    private fun findAccurateCursor(bitmap: Bitmap, bLeft: Int, bTop: Int, cW: Int, cH: Int): Pair<Int, Int>? {
        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val cx = bLeft + c * cW + cW / 2
                val cy = bTop + r * cH + cH / 2

                val leftX = cx - cW / 2 + 1
                var matchCount = 0

                for (dy in -8..8 step 2) {
                    val py = cy + dy
                    if (leftX in 0 until bitmap.width && py in 0 until bitmap.height) {
                        val p = bitmap.getPixel(leftX, py)
                        val pr = Color.red(p)
                        val pg = Color.green(p)
                        val pb = Color.blue(p)
                        if (pg > pr + 25 && pb > pr + 15 && pg in 85..195) {
                            matchCount++
                        }
                    }
                }

                if (matchCount >= 5) {
                    return Pair(r, c)
                }
            }
        }
        return null
    }

    private fun getGemAtCenter(bitmap: Bitmap, cx: Int, cy: Int): Int {
        var tr = 0
        var tg = 0
        var tb = 0
        var count = 0

        for (dx in -1..1) {
            for (dy in -1..1) {
                val px = cx + dx
                val py = cy + dy
                if (px in 0 until bitmap.width && py in 0 until bitmap.height) {
                    val p = bitmap.getPixel(px, py)
                    tr += Color.red(p)
                    tg += Color.green(p)
                    tb += Color.blue(p)
                    count++
                }
            }
        }

        if (count == 0) return BoardSolver.EMPTY

        val avgR = tr / count
        val avgG = tg / count
        val avgB = tb / count

        val hsv = FloatArray(3)
        Color.RGBToHSV(avgR, avgG, avgB, hsv)
        val h = hsv[0]
        val s = hsv[1]
        val v = hsv[2]

        return when {
            s < 0.12f && v >= 0.92f -> BoardSolver.PEACH
            s < 0.22f && v < 0.90f -> BoardSolver.SWORD
            h in 85f..140f -> BoardSolver.STAR
            h in 32f..65f && s > 0.50f -> BoardSolver.GOLD
            h in 175f..220f && s > 0.35f -> BoardSolver.BAGUA
            h in 245f..285f && s > 0.22f -> BoardSolver.DROP
            h in 310f..350f && s > 0.40f -> BoardSolver.HEART
            else -> BoardSolver.EMPTY
        }
    }

    private fun retryNext(delayMs: Long) {
        handler.postDelayed({ loopTurn() }, delayMs)
    }

    override fun onDestroy() {
        isRunning = false
        instance = null
        super.onDestroy()
    }
}
